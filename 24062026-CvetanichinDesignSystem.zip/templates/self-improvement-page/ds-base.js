(() => {
  const base = '../..';
  for (const p of ['styles.css', 'tokens/themes/selfimprovement.css']) {
    const l = document.createElement('link');
    l.rel = 'stylesheet'; l.href = base + '/' + p;
    document.head.appendChild(l);
  }
  const s = document.createElement('script');
  s.src = base + '/_ds_bundle.js';
  s.onerror = () => console.error('ds-base.js: failed to load ' + s.src + ' — if consuming, point base at the bound _ds/<folder>');
  document.head.appendChild(s);
})();
